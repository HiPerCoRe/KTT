#pragma once

namespace ktt
{

enum class ThreadSizeUsage
{
    Basic,
    MatchThreadModifiers
};

} // namespace ktt
