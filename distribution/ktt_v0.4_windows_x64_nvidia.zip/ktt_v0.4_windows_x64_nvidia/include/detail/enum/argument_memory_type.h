#pragma once

namespace ktt
{

enum class ArgumentMemoryType
{
    ReadOnly,
    WriteOnly,
    ReadWrite
};

} // namespace ktt
