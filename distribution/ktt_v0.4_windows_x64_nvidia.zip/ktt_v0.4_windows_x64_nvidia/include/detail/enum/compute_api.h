#pragma once

namespace ktt
{

enum class ComputeApi
{
    Opencl,
    Cuda
};

} // namespace ktt
