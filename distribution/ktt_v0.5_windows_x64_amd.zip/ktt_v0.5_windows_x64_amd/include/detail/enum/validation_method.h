#pragma once

namespace ktt
{

enum class ValidationMethod
{
    AbsoluteDifference,
    SideBySideComparison
};

} // namespace ktt
