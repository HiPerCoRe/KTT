#pragma once

namespace ktt
{

enum class DimensionVectorType
{
    Global,
    Local
};

} // namespace ktt
