#pragma once

namespace ktt
{

enum class RunMode
{
    Tuning,
    Computation
};

} // namespace ktt
