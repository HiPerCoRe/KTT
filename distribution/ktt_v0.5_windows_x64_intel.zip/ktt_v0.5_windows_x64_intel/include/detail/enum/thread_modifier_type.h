#pragma once

namespace ktt
{

enum class ThreadModifierType
{
    None,
    Global,
    Local
};

} // namespace ktt
