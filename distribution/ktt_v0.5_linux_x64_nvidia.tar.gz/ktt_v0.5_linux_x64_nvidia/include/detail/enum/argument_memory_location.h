#pragma once

namespace ktt
{

enum class ArgumentMemoryLocation
{
    Device,
    Host,
    HostZeroCopy
};

} // namespace ktt
