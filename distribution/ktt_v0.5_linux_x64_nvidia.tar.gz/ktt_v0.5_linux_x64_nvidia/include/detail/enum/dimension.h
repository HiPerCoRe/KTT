#pragma once

namespace ktt
{

enum class Dimension
{
    X,
    Y,
    Z
};

} // namespace ktt
