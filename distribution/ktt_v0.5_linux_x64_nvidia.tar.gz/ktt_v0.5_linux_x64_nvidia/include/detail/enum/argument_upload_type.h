#pragma once

namespace ktt
{

enum class ArgumentUploadType
{
    Scalar,
    Vector,
    Local
};

} // namespace ktt
