#pragma once

namespace ktt
{

enum class ThreadModifierAction
{
    Add,
    Subtract,
    Multiply,
    Divide
};

} // namespace ktt
