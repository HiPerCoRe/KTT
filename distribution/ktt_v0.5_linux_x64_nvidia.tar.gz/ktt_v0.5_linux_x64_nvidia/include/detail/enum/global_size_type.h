#pragma once

namespace ktt
{

enum class GlobalSizeType
{
    Opencl,
    Cuda,
    Vulkan
};

} // namespace ktt
