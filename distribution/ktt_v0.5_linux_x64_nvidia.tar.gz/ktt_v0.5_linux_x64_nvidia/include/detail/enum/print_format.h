#pragma once

namespace ktt
{

enum class PrintFormat
{
    Verbose,
    CSV
};

} // namespace ktt
