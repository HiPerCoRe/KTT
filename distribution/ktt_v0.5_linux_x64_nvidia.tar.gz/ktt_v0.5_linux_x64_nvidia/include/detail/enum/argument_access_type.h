#pragma once

namespace ktt
{

enum class ArgumentAccessType
{
    ReadOnly,
    WriteOnly,
    ReadWrite
};

} // namespace ktt
