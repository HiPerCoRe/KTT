#pragma once

namespace ktt
{

enum class ComputeApi
{
    Opencl,
    Cuda,
    Vulkan
};

} // namespace ktt
