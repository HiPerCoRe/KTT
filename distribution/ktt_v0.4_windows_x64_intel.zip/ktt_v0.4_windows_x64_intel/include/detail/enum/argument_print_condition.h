#pragma once

namespace ktt
{

enum class ArgumentPrintCondition
{
    All,
    ValidOnly,
    InvalidOnly
};

} // namespace ktt
